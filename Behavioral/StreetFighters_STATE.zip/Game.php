<?php

require_once 'States/Crazy.php';
require_once 'States/Healthy.php';
require_once 'States/KO.php';

class Game
{
    private $Fighter1;
    private $Fighter2;

    public function __construct(Fighter $Fighter1, Fighter $Fighter2)
    {
        $this->Fighter1 = $Fighter1;
        $this->Fighter2 = $Fighter2;
    }

    public function startGame()
    {
        $states = [
            new Healthy(),
            new KO(),
            new Rage(),
        ];

        while (! $this->Fighter1->isDead() || ! $this->Fighter1->isDead()) {
            $this->Fighter1->attack($this->Fighter2);
            $this->Fighter2->attack($this->Fighter1);

            $this->Fighter1->changeState($states[array_rand($states, 1)]);
            $this->Fighter2->changeState($states[array_rand($states, 1)]);

        }

        if ($this->Fighter1->isDead()) {
            echo $this->Fighter1->name() . ' a gagné le combat ! ✨';
        } else {
            echo $this->Fighter2->name() . ' a gagné le combat ! ✨';
        }
    }
}
