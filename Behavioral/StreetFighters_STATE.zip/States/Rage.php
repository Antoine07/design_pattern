<?php

require_once 'Fighter.php';
require_once 'FighterState.php';

final class Rage implements FighterState
{
    /** @var Fighter */
    private $Fighter;
    
    public function attack(Fighter $Fighter) : void
    {
        // un pourcentage de chance de se blesser
        if ($this->isTooMuchAngry())
        {
            // @TODO : le combattant se blesse tout seule, du fait de sa propre force...

            
            echo $this->Fighter->name() . ' est fou et s\'inflige des dégats' . PHP_EOL;
        } else {
            $Fighter->healthPoints -= $this->Fighter->strength();
        
            echo $this->Fighter->name() . ' attaque malgré sa folie' . PHP_EOL;
        }
        
    }

    public function setFighter(Fighter $Fighter) : FighterState
    {
        $this->Fighter = $Fighter;
        
        return $this;
    }

    private function isTooMuchAngry() : bool
    {
        // @TODO : retourner une condition aléatoire (cf fonction rand() de PHP)
        return true;
    }
}