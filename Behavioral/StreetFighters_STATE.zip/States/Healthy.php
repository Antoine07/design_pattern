<?php

require_once 'Fighter.php';
require_once 'FighterState.php';

final class Healthy implements FighterState
{
    /** @var Fighter */
    private $Fighter;
    
    public function attack(Fighter $Fighter) : void
    {
        // @TODO : le combattant attaque à l'aide de sa force.


        echo $this->Fighter->name() . ' attaque !' . PHP_EOL;
    }

    public function setFighter(Fighter $Fighter) : FighterState
    {
        $this->Fighter = $Fighter;
        
        return $this;
    }
}
