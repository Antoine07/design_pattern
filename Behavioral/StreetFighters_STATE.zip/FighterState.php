<?php

require_once 'Fighter.php';

interface FighterState
{
    public function attack(Fighter $fighter) : void;
    
    public function setFighter(Fighter $fighter) : FighterState;
}
